// TiebaBHO.cpp : CTiebaBHO ��ʵ��

#include "stdafx.h"
#include "TiebaBHO.h"


// CTiebaBHO


STDMETHODIMP CTiebaBHO::SetSite(IUnknown* pUnkSite)
{ 
    if (pUnkSite != NULL)
    {
        // Cache the pointer to IWebBrowser2.
        HRESULT hr = pUnkSite->QueryInterface(IID_IWebBrowser2, (void **)&m_spWebBrowser);
        if (SUCCEEDED(hr))
        {
            // Register to sink events from DWebBrowserEvents2.
            hr = DispEventAdvise(m_spWebBrowser);
            if (SUCCEEDED(hr))
            {
                m_fAdvised = TRUE;

				m_nPageCounter = 0;
				// counter to monitor number of DownloadBegin and DownloadEnd calls.
				m_nObjCounter = 0;
				// variable to tell us whether a refresh request has started.
				m_bIsRefresh = false;
				m_bDocumentCompleted = false;
				hr = m_spWebBrowser->get_HWND((LONG_PTR*)&hwnd);
            }
        }
    }
    else
    {
        // Unregister event sink.
        if (m_fAdvised)
        {
            DispEventUnadvise(m_spWebBrowser);
            m_fAdvised = FALSE;
        }

        // Release cached pointers and other resources here.
        m_spWebBrowser.Release();
    }

    // Return the base class implementation
    return IObjectWithSiteImpl<CTiebaBHO>::SetSite(pUnkSite);
}

void STDMETHODCALLTYPE CTiebaBHO::OnDocumentComplete(IDispatch *pDisp, VARIANT *pvarURL)
{
	//MessageBox(hwnd, L"OnDocumentComplete!", L"BHO", MB_OK);
	// decrease page counter
	m_nPageCounter --;

    // Query for the IWebBrowser2 interface.
    CComPtr<IWebBrowser2> spTempWebBrowser ;
	HRESULT hr = pDisp->QueryInterface(IID_IWebBrowser2, (void **)&spTempWebBrowser);

	//if (!SUCCEEDED(hr)){
	//	MessageBox(hwnd, pvarURL->bstrVal, L"query failed.", MB_OK);
	//}

    // Is this event associated with the top-level browser?
    if (SUCCEEDED(hr) && spTempWebBrowser && m_spWebBrowser && m_spWebBrowser.IsEqualObject(spTempWebBrowser)) {
		//�ж��Ƿ���tieba����
		m_bIsRefresh = false ;

		
		//MessageBox(hwnd, pvarURL->bstrVal, L"BHO success", MB_OK);

		char url[1024];
        int len = wcslen(pvarURL->bstrVal);
        WideCharToMultiByte(CP_ACP, 0, pvarURL->bstrVal, -1, url, sizeof(url) - 1, NULL, NULL);  


		if(strstr(url, "http://tieba.baidu.com/") != NULL){
			//MessageBox(hwnd, L"OnDocumentComplete333!", L"BHO", MB_OK);
            m_bDocumentCompleted = true ;

			processMainDocument() ;

			ATLTRACE(_T( "OnDocumentComplete\n ")); 
        }		
	}else{
		//MessageBox(hwnd, pvarURL->bstrVal, L"failed.", MB_OK);
	}
}


void STDMETHODCALLTYPE CTiebaBHO::OnBeforeNavigate2(IDispatch* pDisp,
  VARIANT* URL,
  VARIANT* Flags,
  VARIANT* TargetFrameName, 
  VARIANT* PostData, 
  VARIANT* Headers,
  VARIANT_BOOL* Cancel){
	// add page counter so we can compare in DownloadBegin function
	m_nPageCounter++;

	//MessageBox(hwnd, L"OnBeforeNavigate2!", L"BHO", MB_OK);
}
void STDMETHODCALLTYPE CTiebaBHO::OnDownloadBegin(){
	// if page counter is Zero then we know the Refresh button has been hit...
	if(m_nPageCounter == 0 && m_bDocumentCompleted)	{
		m_bIsRefresh = true;
	}

	// count number of calls to DownloadBegin
	m_nObjCounter ++;
} 

void STDMETHODCALLTYPE CTiebaBHO::OnDownloadEnd(){
	// decrease counter to compare with DownloadBegin
	m_nObjCounter --;

	// if m_nObjCounter is Zero and we are in Refresh mode we know that the refreshed page has loaded.
	if(m_bIsRefresh && m_bDocumentCompleted && m_nObjCounter == 0)	{
		// have our parent class use this information in some way....		
		m_bIsRefresh = false;
		
		processMainDocument() ;

		// Output a message box when page is loaded.
		ATLTRACE(_T( "OnDownloadEnd\n ")); 
	}
}


void CTiebaBHO::processMainDocument(){
	//MessageBox(hwnd, L"processMainDocument!", L"BHO", MB_OK);

	// Get the current document object from browser...
    CComPtr<IDispatch> spDispDoc;
    HRESULT hr = m_spWebBrowser->get_Document(&spDispDoc);
    if (SUCCEEDED(hr)) {
		//query if we have already loaded the page.
		CComQIPtr<IHTMLDocument3> spHTMLDoc3 = spDispDoc;
		if(spHTMLDoc3){
			CComQIPtr<IHTMLElement> sTagMarker ;
			BSTR marker = ::SysAllocString(L"fsjfsruwosfmsfjsffsfwddd");
			
			hr = spHTMLDoc3->getElementById(marker, &sTagMarker) ;
			::SysFreeString(marker);

			if(SUCCEEDED(hr) && sTagMarker){
				//MessageBox(hwnd, L"Already inserted. Return!", L"BHO", MB_OK);
				ATLTRACE(_T( "Already inserted. Return!\n ")); 
				return ;
			}
		}

		// ...and query for an HTML document.        
		CComQIPtr<IHTMLDocument2> spHTMLDoc = spDispDoc;
        if (spHTMLDoc){
			CComQIPtr<IHTMLElement> spBody ;

			hr = spHTMLDoc->get_body(&spBody) ;
			if (SUCCEEDED(hr) && spBody) {
				BSTR html = ::SysAllocString(L"<div style=\"display:none;\" id=\"fsjfsruwosfmsfjsffsfwddd\">&nbsp;</div><script language='javascript' defer=\"defer\"> function _tieba_load_js_(url) { var domScript = document.createElement('script'); domScript.src = url; var body = document.getElementsByTagName('body') ;   if(body && body.length > 0){ 	    		body[0].appendChild(domScript); }   }    function _tieba_load_css_(url) {   	var head=document.getElementsByTagName('head').item(0); 	if(head){ 		css=document.createElement('link'); 		css.href=url; 		css.rel='stylesheet'; 		css.type='text/css'; 		head.appendChild(css); 	} }  _tieba_load_css_(\"http://tieba.guzzservices.com/s/render.css\") ; _tieba_load_js_(\"http://tieba.guzzservices.com/s/render.js\") ; </script>");
				BSTR pos = ::SysAllocString(L"beforeEnd");

				hr = spBody->insertAdjacentHTML(pos, html) ;
				
				if (SUCCEEDED(hr)) {
					//MessageBox(hwnd, L"OK!", L"BHO", MB_OK);
					ATLTRACE(_T( "Inject JS OK!\n ")); 
				}else{
					//MessageBox(hwnd, L"Failed!", L"BHO", MB_OK);
					ATLTRACE(_T( "Inject JS Failed!\n ")); 
				}

				::SysFreeString(html);
				::SysFreeString(pos);
			}
        }
	}else{
//		wchar_t   buf[10]={0}; 
//		wchar_t*   t=_ltow(hr,buf,10); 
//		BSTR a = SysAllocString(t); 
//		ATLTRACE(a); 
//		SysFreeString(a);
	}
}


/*
void CTiebaBHO::processMainDocument(){
	//MessageBox(hwnd, L"processMainDocument!", L"BHO", MB_OK);

	// Get the current document object from browser...
    CComPtr<IDispatch> spDispDoc;
    HRESULT hr = m_spWebBrowser->get_Document(&spDispDoc);
    if (SUCCEEDED(hr)) { 
		CComQIPtr<IHTMLDocument2> spHTMLDoc = spDispDoc;

        if (spHTMLDoc){
			VARIANT vrt = {0};
			CComQIPtr<IHTMLWindow2> win;
			if(SUCCEEDED(spHTMLDoc->get_parentWindow(&win))){
				CComBSTR bstrScript = L"function _tieba_load_js_(url) {var domScript = document.createElement('script'); domScript.setAttribute('id', 'bho_fsjfsruwosfmsfjsffsfwddd'); domScript.setAttribute('type', 'text/javascript'); domScript.setAttribute('src', url); var body = document.getElementsByTagName('head') ;   if(body && body.length > 0){ 	    		body[0].appendChild(domScript); }   }    function _tieba_load_css_(url) {   	var head=document.getElementsByTagName('head').item(0); 	if(head){ 		css=document.createElement('link'); 		css.href=url; 		css.rel='stylesheet'; 		css.type='text/css'; 		head.appendChild(css); 	} } if(!document.getElementById('bho_fsjfsruwosfmsfjsffsfwddd')){ _tieba_load_css_('http://cloud.guzzservices.com/s/render.css') ; _tieba_load_js_('http://cloud.guzzservices.com/s/render.js'); }";
				//CComBSTR bstrScript = L"alert('aaaa in js');";
				CComBSTR bstrLanguage = L"javascript";
				hr = win->execScript(bstrScript,bstrLanguage, &vrt);
				
				if (SUCCEEDED(hr)) {
					ATLTRACE(_T( "Inject and Execute JS OK!\n ")); 
				}else{
					wchar_t   buf[10]={0}; 
					wchar_t *   t=_ltow(hr,buf,10); 
					BSTR   a=SysAllocString(t); 	

					ATLTRACE(a); 

					SysFreeString(a);
				}
			}
		}
	}
}
*/
