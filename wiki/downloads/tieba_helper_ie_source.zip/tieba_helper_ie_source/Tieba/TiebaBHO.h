// TiebaBHO.h : CTiebaBHO ������

#pragma once
#include "resource.h"       // ������

#include "Tieba.h"
#include <shlguid.h>     // IID_IWebBrowser2, DIID_DWebBrowserEvents2, etc.
#include <exdispid.h> // DISPID_DOCUMENTCOMPLETE, etc.
#include <mshtml.h>         // DOM interfaces
#include <exdisp.h> //For IWebBrowser2* and others
#include <exdispid.h>

#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Windows CE ƽ̨(�粻�ṩ��ȫ DCOM ֧�ֵ� Windows Mobile ƽ̨)���޷���ȷ֧�ֵ��߳� COM ���󡣶��� _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA ��ǿ�� ATL ֧�ִ������߳� COM ����ʵ�ֲ�����ʹ���䵥�߳� COM ����ʵ�֡�rgs �ļ��е��߳�ģ���ѱ�����Ϊ��Free����ԭ���Ǹ�ģ���Ƿ� DCOM Windows CE ƽ̨֧�ֵ�Ψһ�߳�ģ�͡�"
#endif



// CTiebaBHO

class ATL_NO_VTABLE CTiebaBHO :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CTiebaBHO, &CLSID_TiebaBHO>,
	public IObjectWithSiteImpl<CTiebaBHO>,
	public IDispatchImpl<ITiebaBHO, &IID_ITiebaBHO, &LIBID_TiebaLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
	public IDispEventImpl<1, CTiebaBHO, &DIID_DWebBrowserEvents2, &LIBID_SHDocVw, 1, 1>
{
public:
	CTiebaBHO()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_TIEBABHO)

DECLARE_NOT_AGGREGATABLE(CTiebaBHO)

BEGIN_COM_MAP(CTiebaBHO)
	COM_INTERFACE_ENTRY(ITiebaBHO)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IObjectWithSite)
END_COM_MAP()



	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}


public:
	STDMETHOD(SetSite)(IUnknown *pUnkSite);

BEGIN_SINK_MAP(CTiebaBHO)
    SINK_ENTRY_EX(1, DIID_DWebBrowserEvents2, DISPID_DOCUMENTCOMPLETE, OnDocumentComplete)
	SINK_ENTRY_EX(1, DIID_DWebBrowserEvents2, DISPID_BEFORENAVIGATE2, OnBeforeNavigate2)
	SINK_ENTRY_EX(1, DIID_DWebBrowserEvents2, DISPID_DOWNLOADBEGIN, OnDownloadBegin)
	SINK_ENTRY_EX(1, DIID_DWebBrowserEvents2, DISPID_DOWNLOADCOMPLETE, OnDownloadEnd)
END_SINK_MAP()

    // DWebBrowserEvents2
    void STDMETHODCALLTYPE OnDocumentComplete(IDispatch *pDisp, VARIANT *pvarURL); 
    void STDMETHODCALLTYPE OnBeforeNavigate2(IDispatch* pDisp, VARIANT* URL, 
											  VARIANT* pvtFlags,
											  VARIANT* pvtTargetFrameName, 
											  VARIANT* pvtPostData, 
											  VARIANT* pvtHeaders,
											  VARIANT_BOOL* pvbCancel);
	void STDMETHODCALLTYPE OnDownloadBegin(); 
    void STDMETHODCALLTYPE OnDownloadEnd(); 

private:
    void processMainDocument() ;


private:
    CComPtr<IWebBrowser2>  m_spWebBrowser;
	BOOL m_fAdvised; 

	// counter to monitor number of requests to BeforeNavigate2 vs number of requests to DownloadBegin.
	int m_nPageCounter;
	// counter to monitor number of DownloadBegin and DownloadEnd calls.
	int m_nObjCounter;
	// variable to tell us whether a refresh request has started.	
	BOOL m_bIsRefresh;

	BOOL m_bDocumentCompleted;

	HWND hwnd; 

};

OBJECT_ENTRY_AUTO(__uuidof(TiebaBHO), CTiebaBHO)
